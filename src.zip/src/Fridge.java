public class Fridge extends Appliance {
    double cubicFeet;
    boolean hasFreezer;

    public Fridge(){
        price=100;
        stockQuantity=5;
        wattage=10;
        brand="Samsung";
        cubicFeet=10;
        hasFreezer=true;
        color="Black";
        soldQuantity=0;
    }
    public Fridge(double price, int quantity, int wattage, String color, String brand,
                  double cubicFeet, boolean freezer){
     this.price=price;
     stockQuantity=quantity;
     this.wattage=wattage;
     this.brand=brand;
     this.cubicFeet=cubicFeet;
     hasFreezer=freezer;
     this.color=color;
     this.soldQuantity=0;
    }
    public String toString() {
        if (hasFreezer) {
            return cubicFeet + " cu. ft. "+brand+" Fridge with Freezer ("  + color + ", "+wattage+" watts)   ("
                    +price+" dollars each, "+stockQuantity+" in stock, "+soldQuantity+" sold)";
        }
        else {
            return cubicFeet + " cu. ft. "+brand+" Fridge ("  + color + ", "+wattage+" watts)   ("
                    +price+" dollars each, "+stockQuantity+" in stock, "+soldQuantity+" sold)";
        }
    }
}