public class Product {
    double price;
    int stockQuantity;
    int soldQuantity;

    public Product(double price,int quantity){
        this.price=price;
        stockQuantity=quantity;
        soldQuantity=0;
    }
    public Product(){
        price=500;
        stockQuantity=5;
        soldQuantity=0;
    }

    public double sellUnits(int amount){
        if (stockQuantity>=amount){
            stockQuantity-=amount;
            soldQuantity+=amount;
            return amount*this.price;
        }
        else{
            return 0.0;
        }
    }
}
