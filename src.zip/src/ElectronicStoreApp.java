import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.stage.Stage;
import javafx.scene.input.*;
import javafx.scene.Scene;
import javafx.event.*;
import java.util.ArrayList;

public class ElectronicStoreApp extends Application {
    ElectronicStoreView view;
    ElectronicStore model;
    Stage primaryStage;


    public void start(Stage primaryStage) {
        this.primaryStage=primaryStage;
        model= ElectronicStore.createStore();
        view= new ElectronicStoreView(model);
        view.remove.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {handleRemove();
            }
        });
        view.getCurrCart().setOnMouseReleased(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent mouseEvent) {
               view.update();
            }
        });
        view.getStorestock().setOnMouseReleased(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent mouseEvent) {
                view.update();
            }
        });
        view.getAddtocart().setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                handleAdd();
            }
        });
        view.getCompleteSale().setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                model.numsales++;
                model.revenue+=view.cartTotal;
                for(int i=0;i<model.cart.size();i++){
                    for(int j=0;j<model.products.length;j++){
                        if(model.products[j]!=null){
                            if(model.products[j].equals(model.cart.get(i))){
                                model.products[j].soldQuantity++;
                            }
                        }}
                }
                view.cartTotal=0;
                model.cart=new ArrayList<>();
                view.update();
            }
        });
        view.getResetStore().setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                restart();
            }
        });
        primaryStage.setTitle("Electronic Store Application - "+model.getName());
        primaryStage.setResizable(false);
        primaryStage.setScene(new Scene(view, 800, 400)); // Set size of window
        primaryStage.show();
        view.update();
    }
    public static void main(String[] args) { launch(args); }
    public void handleRemove(){
        int selection = view.currCart.getSelectionModel().getSelectedIndex();
        if(selection>=0){
            view.cartTotal-=model.cart.get(selection).price;
            for(int i=0;i<model.products.length;i++){
                if(model.products[i]!=null){
                if(model.products[i].equals(model.cart.get(selection))){
                    model.products[i].stockQuantity++;
                    model.soldOutIndex.remove(Integer.valueOf(i));
                }
            }}
            model.cart.remove(selection);
        }view.update();
        if(view.currCart.getItems().size()>0){
        view.currCart.getSelectionModel().select(selection);
        view.remove.setDisable(false);}
    }
    public void handleAdd(){

        int selection =view.storestock.getSelectionModel().getSelectedIndex();
        int origSelection=selection;
        for(int i=0;i<model.soldOutIndex.size();i++){
            if(selection>=model.soldOutIndex.get(i)){
                selection++;
            }
        }
        if(model.products[selection].stockQuantity>=1){
        model.products[selection].stockQuantity--;
        model.cart.add(model.products[selection]);
        view.cartTotal+=model.products[selection].price;

        view.update();
        if(view.storestock.getItems().size()>0){
        view.storestock.getSelectionModel().select(origSelection);
        view.addtocart.setDisable(false);}

    }
    }
    public void restart(){
            start(primaryStage);
    }

}
