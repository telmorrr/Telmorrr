import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;
public class ElectronicStore {
    final int MAX_PRODUCTS = 10;
    String name;
    double revenue;
    Product[] products;
    int numsales;
    int numofproducts;
    ArrayList<Product> cart=new ArrayList<>();
    ElectronicStoreApp app;
    ArrayList<Integer> soldOutIndex=new ArrayList<>();




    public String getName(){
        return name;
    }

    public boolean addProduct(Product p){
        for(int i=0; i<products.length;i++){
            if(products[i]==null){
                products[i]=p;
                numofproducts++;
               return true;
            }
        }
        return false;
    }
    public void sellProducts(int item, int amount){
        if(item<=MAX_PRODUCTS && products[item]!=null && amount>=0 ) {
            revenue+=products[item].sellUnits(amount);
        }
    }
    public ArrayList<String> getstock(){
        if (numofproducts<=0){
            return new ArrayList<>();
        }
        ArrayList<String> temp = new ArrayList<>();
        for(int i=0;i<products.length;i++){
            if(products[i]!=null&&(products[i].stockQuantity!=0)){
            temp.add(products[i].toString());}
            else if(products[i]!=null){
                if (soldOutIndex.size()>0 && soldOutIndex.contains(i)){}
                else{
                soldOutIndex.add(i);
                Collections.sort(soldOutIndex);
            }
            }
        }
        return temp;
    }
    public String[] getCart(){
        if (cart.size()<=0){
            return new String[0];
        }
        String[] temp = new String[cart.size()];
        for(int i=0;i<temp.length;i++){
            temp[i]=cart.get(i).toString();
        }
        return temp;
    }

    public void sellProducts(){
        printStock();
        Scanner in= new Scanner(System.in);
        int index= in.nextInt();
        int units= in.nextInt();
        if(index>=0 && units>0 && index<=MAX_PRODUCTS && products[index]!=null){
        sellProducts(index,units);
    }
    }
    public ElectronicStore(String name){
        this.name=name;
        revenue=0;
        numsales=0;
        products= new Product[MAX_PRODUCTS];
    }
    public ElectronicStore(){
        name="Unnamed store";
    }

    public double getRevenue() {
        return revenue;
    }

    public void printStock(){
        for(int i=0; i<products.length;i++){
            if(products[i]==null){
                break;}
            System.out.println(i +". " + products[i]);
        }
        }
    public static ElectronicStore createStore(){
        ElectronicStore store1 = new ElectronicStore("Watts Up Electronics");
        Desktop d1 = new Desktop(100, 10, 3.0, 16, false, 250, "Compact");
        Desktop d2 = new Desktop(200, 10, 4.0, 32, true, 500, "Server");
        Laptop l1 = new Laptop(150, 10, 2.5, 16, true, 250, 15);
        Laptop l2 = new Laptop(250, 10, 3.5, 24, true, 500, 16);
        Fridge f1 = new Fridge(500, 10, 250, "White", "Sub Zero", 15.5, false);
        Fridge f2 = new Fridge(750, 10, 125, "Stainless Steel", "Sub Zero", 23, true);
        ToasterOven t1 = new ToasterOven(25, 10, 50, "Black", "Danby", 8, false);
        ToasterOven t2 = new ToasterOven(75, 10, 50, "Silver", "Toasty", 12, true);
        store1.addProduct(d1);
        store1.addProduct(d2);
        store1.addProduct(l1);
        store1.addProduct(l2);
        store1.addProduct(f1);
        store1.addProduct(f2);
        store1.addProduct(t1);
        store1.addProduct(t2);
        return store1;
    }
    }



