import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.lang.ref.PhantomReference;
import java.util.ArrayList;
import java.util.List;


public class ElectronicStoreView extends Pane {
    Button resetStore;
    Button addtocart;
    Button remove;
    Button completeSale;
    ListView<String> mostpoplist;
    ListView<String> storestock;
    ListView<String> currCart;
    ElectronicStore model;
    TextField salesnumber;
    TextField revenue;
    TextField dollarpersale;
    Label label7;
    int cartTotal;

    public ElectronicStoreView(ElectronicStore iModel){
        model = iModel;
        cartTotal=0;
        currCart= new ListView<String>();
        currCart.relocate(525,40);
        currCart.setPrefSize(265,300);
        storestock= new ListView<String>();
        storestock.setPrefSize(265,300);
        storestock.relocate(235,40);
        dollarpersale=new TextField();
        dollarpersale.setDisable(true);
        dollarpersale.setPrefSize(90,15);
        dollarpersale.relocate(70,100);
        revenue= new TextField();
        revenue.setDisable(true);
        revenue.relocate(70,70);
        revenue.setPrefSize(90,15);
        salesnumber= new TextField();
        salesnumber.setDisable(true);
        salesnumber.relocate(70,40);
        salesnumber.setPrefSize(90,15);
        mostpoplist= new ListView<String>();
        mostpoplist.relocate(10,150);
        mostpoplist.setPrefSize(200,200);
        addtocart= new Button("Add to Cart");
        addtocart.relocate(300, 360);
        addtocart.setPrefSize(120, 20);
        addtocart.setDisable(true);
        resetStore= new Button("Reset Store");
        resetStore.relocate(20,360);
        resetStore.setPrefSize(120,20);
        remove = new Button("Remove from Cart");
        remove.relocate(540,360);
        remove.setPrefSize(120,20);
        remove.setDisable(true);
        completeSale= new Button("Complete Sale");
        completeSale.setPrefSize(120,20);
        completeSale.relocate(660,360);
        completeSale.setDisable(true);
        Label label1= new Label("Store Summary:");
        label1.relocate(40,10);
        Label label2= new Label("# Sales:");
        label2.relocate(10,40);
        Label label3= new Label("Revenue:");
        label3.relocate(10,70);
        Label label4= new Label("$ / Sale:");
        label4.relocate(10,100);
        Label label5= new Label("Most Popular Items:");
        label5.relocate(40,130);
        Label label6= new Label("Store Stock:");
        label6.relocate(335,10);
        label7= new Label("Current Cart ($"+cartTotal+"):");
        label7.relocate(600,10);
        dollarpersale.setText("N/A");
        getChildren().addAll(currCart,storestock,revenue,dollarpersale,salesnumber,mostpoplist,resetStore,completeSale,remove,addtocart,label1,label2,label3,label4,label5,label6,label7);

    }

    public Button getResetStore() {
        return resetStore;
    }

    public ListView<String> getMostpoplist() {
        return mostpoplist;
    }

    public ListView<String> getStorestock() {
        return storestock;
    }

    public ListView<String> getCurrCart() {
        return currCart;
    }

    public Button getAddtocart() {
        return addtocart;
    }

    public Button getRemove() {
        return remove;
    }

    public Button getCompleteSale() {
        return completeSale;
    }
    public ArrayList<String> updateMostPop(){
        ArrayList<String> tempmostpop =new ArrayList<>();
        Product[] tempprod= new Product[model.MAX_PRODUCTS];
        for(int i=0;i<model.MAX_PRODUCTS;i++){
            tempprod[i]=model.products[i];
        }
        for(int j=0;j<3;j++){
            int max =-1;
            String maxpro=model.products[0].toString();
            int index=0;
            for(int i=0;i<tempprod.length;i++){
                if(tempprod[i]!=null && tempprod[i].soldQuantity>=max){
                    max=tempprod[i].soldQuantity;
                    maxpro=model.products[i].toString();
                    index=i;
                }
            }
            tempmostpop.add(maxpro);
            tempprod[index]=null;
        }
        return tempmostpop;
    }
    public void update(){

        label7.setText("Current Cart ($"+cartTotal+"):");
        mostpoplist.setItems(FXCollections.observableArrayList(updateMostPop()));
        storestock.setItems(FXCollections.observableArrayList(model.getstock()));
        currCart.setItems(FXCollections.observableArrayList(model.getCart()));
        int selection= storestock.getSelectionModel().getSelectedIndex();
        int selection2= currCart.getSelectionModel().getSelectedIndex();
        if(selection==-1){
            addtocart.setDisable(true); }
        else { addtocart.setDisable(false); }
        if(selection2==-1){ remove.setDisable(true); }
        else { remove.setDisable(false); }
        if(model.getCart().length>=1) { completeSale.setDisable(false); }
        else{ completeSale.setDisable(true); }
        salesnumber.setText(""+model.numsales);
        revenue.setText(""+model.revenue);
        if (model.numsales!=0){
        dollarpersale.setText(""+(model.revenue/model.numsales));
    }
    }
}
