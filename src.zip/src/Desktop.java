public class Desktop extends Computer{
    String profile;


    public Desktop(double price, int quantity, double cpuSpeed, int ram, boolean ssd, int storage, String profile){
        this.price = price;
        stockQuantity = quantity;
        this.cpuSpeed = cpuSpeed;
        this.ram = ram;
        this.ssd= ssd;
        this.storage= storage;
        this.profile=profile;
        this.soldQuantity=0;
    }

    public Desktop(){
        soldQuantity=0;
        price = 500;
        stockQuantity = 1;
        cpuSpeed = 3.0;
        ram = 8;
        ssd= true;
        storage= 500;
        soldQuantity=0;
        profile="Compact";
    }

    public String toString() {
        if (ssd) {
            return profile+ " Desktop PC with "+ cpuSpeed+ "ghz CPU, " + ram + "GB RAM, " + storage + "SSD drive. (" +
                    price +" dollars each, "+ stockQuantity + " in stock, " + soldQuantity+" sold)";
        }
        else {
            return profile+ " Desktop PC with "+ cpuSpeed+ "ghz CPU, " + ram + "GB RAM, " + storage + "HDD drive. (" +
                    price +" dollars each, "+ stockQuantity + " in stock, " + soldQuantity+" sold)";
        }
    }

}