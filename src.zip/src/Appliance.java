public class Appliance extends Computer {
    int wattage;
    String color;
    String brand;
}
