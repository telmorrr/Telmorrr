public class Laptop extends  Computer{
    double screenSize;

    public Laptop(double price, int quantity, double cpuSpeed, int ram, boolean ssd, int storage,double screenSize ) {
        this.price = price;
        stockQuantity = quantity;
        this.cpuSpeed = cpuSpeed;
        this.ram = ram;
        this.ssd= ssd;
        this.storage= storage;
        this.soldQuantity=0;
        this.screenSize=screenSize;
    }

    public Laptop(){
        soldQuantity=0;
        price = 500;
        stockQuantity = 1;
        cpuSpeed = 3.0;
        ram = 8;
        ssd= true;
        storage= 500;
        soldQuantity=0;
        screenSize=15;
    }

    public String toString() {
        if (ssd) {
            return screenSize + " inch Laptop PC with "+ cpuSpeed+ "ghz CPU, " + ram + "GB RAM, " + storage + "SSD drive. (" +
                    price +" dollars each, "+ stockQuantity + " in stock, " + soldQuantity+" sold)";
        }
        else {
            return screenSize + " inch Laptop PC with "+ cpuSpeed+ "ghz CPU, " + ram + "GB RAM, " + storage + "HDD drive. (" +
                    price +" dollars each, "+ stockQuantity + " in stock, " + soldQuantity+" sold)";
        }
    }

}