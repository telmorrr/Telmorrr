public class Computer extends Product {
    double cpuSpeed;
    int ram;
    boolean ssd;
    int storage;

}
