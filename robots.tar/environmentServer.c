#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/wait.h>

#include "simulator.h"

Environment    environment;  // The environment that contains all the robots
	struct sockaddr_in 	Addr[MAX_ROBOTS];
	int stopflag=0;
	int numstop=0;
	int                 serverSocket,status;
  struct sockaddr_in  serverAddr, clientAddr;
  int                 status, addrSize, bytesReceived;
  fd_set              readfds, writefds;
  unsigned char                buffer[30];
  char*               response = "OK";
	char*               badresponse = "NOT_OK";
 
void *handleIncomingRequests(void *e) {
	char   online = 1;
	serverSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if (serverSocket < 0) {
    printf("*** SERVER ERROR: Could not open socket.\n");
    exit(-1);
  }

  // Setup the server address
  memset(&serverAddr, 0, sizeof(serverAddr)); // zeros the struct
  serverAddr.sin_family = AF_INET;
  serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
  serverAddr.sin_port = htons((unsigned short) SERVER_PORT);

  // Bind the server socket
  status = bind(serverSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));
  if (status < 0) {
    printf("*** SERVER ERROR: Could not bind socket.\n");
    exit(-1);
  }

  // Wait for robot clients
  while (online) {
    FD_ZERO(&readfds);
    FD_SET(serverSocket, &readfds);
    FD_ZERO(&writefds);
    FD_SET(serverSocket, &writefds);
    status = select(FD_SETSIZE, &readfds, &writefds, NULL, NULL);
    if (status == 0) {
      // Timeout occurred, no client ready
    }
    else if (status < 0) {
      printf("*** SERVER ERROR: Could not select socket.\n");
      exit(-1);
    }
    else {
      addrSize = sizeof(clientAddr);
      bytesReceived = recvfrom(serverSocket, buffer, sizeof(buffer), 0, (struct sockaddr *) &clientAddr, &addrSize);
      if (bytesReceived > 0) {
        buffer[bytesReceived] = '\0';
      }
			//if server gets a STOP from the stop client it turns on a flag
			if(buffer[0]==STOP){
				stopflag=1;
			}
			// if a robot tries to register check if there are too many robots, if <20 send OK else send NOT_OK
			else if(buffer[0]==REGISTER){
				if(environment.numRobots==MAX_ROBOTS){
					buffer[0]=6;
					sendto(serverSocket, buffer, strlen(buffer), 0,(struct sockaddr *) &clientAddr,sizeof(clientAddr));
				}
				else{
					if(environment.numRobots>=2){
						char good=1;	
						int count;
						//loop untill we find a good x,y position for the robot
						while(good){
							count=0;
							environment.robots[environment.numRobots].x=(int)((rand()/(double)RAND_MAX*571)+ROBOT_RADIUS);
							environment.robots[environment.numRobots].y=(int)((rand()/(double)RAND_MAX*571)+ROBOT_RADIUS);
							for(int i=0;i<environment.numRobots-1;i++){
								if(pow((pow(environment.robots[environment.numRobots].x-environment.robots[i].x,2) + pow(environment.robots[environment.numRobots].y-environment.robots[i].y,2)),0.5)>30) 
								count++;
							}
							if(count==environment.numRobots-1)good=0;
						}
					}
					else{
						environment.robots[environment.numRobots].x=(int)((rand()/(double)RAND_MAX*571)+ROBOT_RADIUS);
						environment.robots[environment.numRobots].y=(int)((rand()/(double)RAND_MAX*571)+ROBOT_RADIUS);
					}
					environment.robots[environment.numRobots].direction=(int)((rand()/(double)RAND_MAX*361)-180);
					buffer[0]=5;
					buffer[1]=environment.numRobots;
					buffer[2]=environment.robots[environment.numRobots].x/10;
					buffer[3]=(int)environment.robots[environment.numRobots].x%10;
					buffer[4]=environment.robots[environment.numRobots].y/10;
					buffer[5]=(int)environment.robots[environment.numRobots].y%10;
					if(environment.robots[environment.numRobots].direction<0){
						buffer[6]=1;
						buffer[7]=((-1)*(environment.robots[environment.numRobots].direction));
					}
					else {
						buffer[6]=0;
						buffer[7]=(environment.robots[environment.numRobots].direction);
					}
					buffer[8]='\0';
					environment.numRobots++;
     			sendto(serverSocket, buffer, 10, 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
				}
			}
			//when robot client send status update just update the robot struct variable
			else if(buffer[0]==STATUS_UPDATE){
				int id=buffer[1];
				environment.robots[id].x=buffer[2]*10+buffer[3];
				environment.robots[id].y=buffer[4]*10+buffer[5];
				environment.robots[id].direction=buffer[7];
				if(buffer[6]==1) {environment.robots[id].direction=buffer[7]*-1;}

			}
			// when robot client sends check collision check if the robot will go beyond the env size or if it will collide with another robot
			else if(buffer[0]==CHECK_COLLISION){

				//if the flag is turned on the server will wait until all the robot clients get the STOP SIGNAL and then the server shuts down
				if(stopflag==1){
					buffer[0]=LOST_CONTACT;
					sendto(serverSocket, buffer, 10, 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
					numstop++;
					if(numstop==environment.numRobots){
						environment.shutDown = 1;
						break;
					}
				}
				int i;
				char bol=0;
				int id=buffer[1];
				int direction=environment.robots[id].direction;
				int x=environment.robots[id].x+(ROBOT_SPEED*cos(direction));
				int y=environment.robots[id].y+(ROBOT_SPEED*sin(direction));
				if(x>(ENV_SIZE-ROBOT_RADIUS) || x<ROBOT_RADIUS || y>(ENV_SIZE-ROBOT_RADIUS) || y<ROBOT_RADIUS){
					buffer[0]=NOT_OK_BOUNDARY;
					sendto(serverSocket, buffer, 10, 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
					continue;
				}
				for(i=0;i<environment.numRobots;i++){
					if(i==id) continue;
					
					
					if(pow((pow(x-environment.robots[i].x,2) + pow(y-environment.robots[i].y,2)),0.5)<=30){
						buffer[0]=NOT_OK_COLLIDE;
						bol=1;
						sendto(serverSocket, buffer, 10, 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
						break;
					}
				}
				if(bol==0){
					buffer[0]=OK;
					sendto(serverSocket, buffer, 10, 0,(struct sockaddr *) &clientAddr, sizeof(clientAddr));
				}
			}
      	

    }
  } 

  //close the sockets
  close(serverSocket);
  printf("SERVER: Shutting down.\n");
}

int main() {
	pthread_t t1,t2;
	// So far, the environment is NOT shut down
	environment.shutDown = 0;
	// Set up the random seed
	srand(time(NULL));
	pthread_create(&t1,NULL,handleIncomingRequests,&environment);
	pthread_create(&t2,NULL,redraw,&environment);
	// Spawn an infinite loop to handle incoming requests and update the display
		pthread_join(t1,NULL);
		pthread_join(t2,NULL);
	// Wait for the update and draw threads to complete
	
}
