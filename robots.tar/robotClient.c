#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "simulator.h"




// This is the main function that simulates the "life" of the robot
// The code will exit whenever the robot fails to communicate with the server
int main() {
  
  int id,x,y,dir;
	int rotation=-1;
  // Set up the random seed
  srand(time(NULL));
  int                 clientSocket, addrSize, bytesReceived;
  struct sockaddr_in  clientAddr;

  char                inStr[80];    // stores user input from keyboard
  unsigned char       buffer[80];   // stores sent and received data

  // Create socket
  clientSocket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if (clientSocket < 0) {
    printf("*** CLIENT ERROR: Could open socket.\n");
    exit(-1);
  }

  // Setup address 
  memset(&clientAddr, 0, sizeof(clientAddr));
  clientAddr.sin_family = AF_INET;
  clientAddr.sin_addr.s_addr = inet_addr(SERVER_IP);
  clientAddr.sin_port = htons((unsigned short) SERVER_PORT);
	buffer[0]=1;
	//Sending register request to the server
  sendto(clientSocket, buffer, strlen(buffer), 0,  (struct sockaddr *) &clientAddr, sizeof(clientAddr));
  addrSize = sizeof(clientAddr);
  bytesReceived = recvfrom(clientSocket, buffer, 80, 0,(struct sockaddr *) &clientAddr, &addrSize);
  buffer[bytesReceived] = 0;
	id=buffer[1];
	x=buffer[2]*10+buffer[3];
	y=buffer[4]*10+buffer[5];
	dir=buffer[7];
	if(buffer[6]==1) {dir=dir*-1;}
	//if there are 20 robots the server will refuse and the robot will shutdown
  if (buffer[0]==6){
		close(clientSocket);  //  close the socket !
		printf("CLIENT: Shutting down, cannot add anymore robots since server is at max capacity.\n");
    return 0;
	}
		//loop to send status update and check collisions
  while (1) {
		buffer[0]=STATUS_UPDATE;
		buffer[1]=id;
		buffer[2]=(int)(x/10);
		buffer[3]=(int)(x%10);
		buffer[4]=(int)(y/10);
		buffer[5]=(int)(y%10);
		if(dir<0){
			buffer[6]=1;
			buffer[7]=((-1)*(dir));
		}
		else {
			buffer[6]=0;
			buffer[7]=(dir);
		}
		buffer[8]='\0';
		sendto(clientSocket, buffer, 10, 0,(struct sockaddr *) &clientAddr, addrSize);
		
		buffer[0]=CHECK_COLLISION;
		sendto(clientSocket, buffer, 10, 0,(struct sockaddr *) &clientAddr, addrSize);
	 	bytesReceived = recvfrom(clientSocket, buffer, 80, 0,(struct sockaddr *) &clientAddr, &addrSize);
	 	buffer[bytesReceived] = 0;

		//if the check collision response is ok the robot can move forward
		if(buffer[0]==OK){
			x+=(int)(ROBOT_SPEED*cos(dir));
			y+=(int)(ROBOT_SPEED*sin(dir));
		}

		// else the robot needs to rotate
		else if(buffer[0] == NOT_OK_BOUNDARY){
			if(rotation==-1)
				rotation=(int)((rand()/(double)RAND_MAX*2));
			if(rotation==0)
				if(dir+ROBOT_TURN_ANGLE<=180)
				dir+=ROBOT_TURN_ANGLE;
				else rotation=1;
			if(rotation==1)
				if(dir-ROBOT_TURN_ANGLE>=-180)
				dir-=ROBOT_TURN_ANGLE;
				else rotation=0;
		}
		else if(buffer[0] == NOT_OK_COLLIDE){
			if(rotation==-1)
				rotation=(int)((rand()/(double)RAND_MAX*2));
			if(rotation==0)
				if(dir+ROBOT_TURN_ANGLE<=180)
				dir+=ROBOT_TURN_ANGLE;
				else rotation=1;
			if(rotation==1)
				if(dir-ROBOT_TURN_ANGLE>=-180)
				dir-=ROBOT_TURN_ANGLE;
				else rotation=0;
		}
    else if(buffer[0] == LOST_CONTACT){
      break;
		}
		//usleep(10000);
  } 
  close(clientSocket);  //  close the socket 
  printf("Robot number %d is shutting down.\n",id);
}


