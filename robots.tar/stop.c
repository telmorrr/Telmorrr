#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "simulator.h"

int main() {
  int                 clientSocket, addrSize, bytesReceived;
  struct sockaddr_in  clientAddr;

  char                inStr[80];    // stores user input from keyboard
  char                buffer[80];   // stores sent and received data

  // Create socket
  clientSocket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if (clientSocket < 0) {
    printf("*** CLIENT ERROR: Could open socket.\n");
    exit(-1);
  }

  // Setup address 
  memset(&clientAddr, 0, sizeof(clientAddr));
  clientAddr.sin_family = AF_INET;
  clientAddr.sin_addr.s_addr = inet_addr(SERVER_IP);
  clientAddr.sin_port = htons((unsigned short) SERVER_PORT);
	//send STOP to server
    strcpy(buffer, "2");
		buffer[0]=2;
    sendto(clientSocket, buffer, strlen(buffer), 0,  (struct sockaddr *) &clientAddr, sizeof(clientAddr));
  close(clientSocket);  // to close the socket !
}
